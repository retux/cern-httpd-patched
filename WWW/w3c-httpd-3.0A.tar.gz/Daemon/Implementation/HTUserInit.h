/*                                                                           User Init Module
                                     USER INIT MODULE
                                             
 */
/*
**      (c) COPYRIGHT MIT 1995.
**      Please first read the full copyright statement in the file COPYRIGH.
*/
/*

 */
/*
** On Exit:
**      =0      ok
*/
PUBLIC int HTUserInit NOPARAMS;

/*

   End of declaration module  */
